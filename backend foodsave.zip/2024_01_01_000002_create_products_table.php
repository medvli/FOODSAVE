<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade'); // le commerçant
            $table->string('name');
            $table->text('description')->nullable();
            $table->string('category'); // boulangerie, fruits, legumes, repas, etc.
            $table->integer('quantity');
            $table->string('unit')->default('unité'); // kg, unité, portion
            $table->date('expiration_date');
            $table->time('available_until')->nullable(); // disponible jusqu'à quelle heure
            $table->enum('action_type', ['don', 'prix_solidaire', 'redistribution']);
            $table->decimal('price', 8, 2)->default(0); // 0 si don gratuit
            $table->enum('status', ['disponible', 'reserve', 'collecte', 'expire'])->default('disponible');
            $table->string('image')->nullable();
            $table->decimal('latitude', 10, 7)->nullable();
            $table->decimal('longitude', 10, 7)->nullable();
            $table->boolean('ia_suggested')->default(false); // suggéré par l'IA
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
