<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ReservationController;
use App\Http\Controllers\StatsController;
use App\Http\Controllers\NotificationController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Routes API - FoodSave
|--------------------------------------------------------------------------
|
| Routes publiques (sans authentification)
| Routes protégées (avec token Sanctum)
|
*/

// ═══════════════════════════════════════════════════════════
// ROUTES PUBLIQUES
// ═══════════════════════════════════════════════════════════

// Authentification
Route::post('/register', [AuthController::class, 'register']);
Route::post('/login',    [AuthController::class, 'login']);

// Produits disponibles (visible sans compte)
Route::get('/products',      [ProductController::class, 'index']);
Route::get('/products/{id}', [ProductController::class, 'show']);

// Statistiques globales (pour la section Impact du site)
Route::get('/stats/global', [StatsController::class, 'global']);


// ═══════════════════════════════════════════════════════════
// ROUTES PROTÉGÉES (connexion obligatoire)
// ═══════════════════════════════════════════════════════════

Route::middleware('auth:sanctum')->group(function () {

    // ── Profil utilisateur ───────────────────────────────
    Route::get('/me',           [AuthController::class, 'me']);
    Route::put('/profile',      [AuthController::class, 'updateProfile']);
    Route::post('/logout',      [AuthController::class, 'logout']);

    // ── Produits / Surplus ───────────────────────────────
    Route::post('/products',           [ProductController::class, 'store']);      // Commerçant publie
    Route::put('/products/{id}',       [ProductController::class, 'update']);     // Commerçant modifie
    Route::delete('/products/{id}',    [ProductController::class, 'destroy']);    // Commerçant supprime
    Route::get('/my-products',         [ProductController::class, 'myProducts']); // Mes surplus

    // ── Réservations ─────────────────────────────────────
    Route::post('/reservations',                       [ReservationController::class, 'store']);          // Réserver
    Route::get('/reservations',                        [ReservationController::class, 'index']);          // Mes réservations
    Route::put('/reservations/{id}/confirmer',         [ReservationController::class, 'confirmer']);      // Commerçant confirme
    Route::put('/reservations/{id}/collecter',         [ReservationController::class, 'marquerCollectee']); // Marquer collecté
    Route::put('/reservations/{id}/annuler',           [ReservationController::class, 'annuler']);        // Annuler

    // ── Statistiques par profil ──────────────────────────
    Route::get('/stats/commercant',   [StatsController::class, 'commercant']);
    Route::get('/stats/association',  [StatsController::class, 'association']);
    Route::get('/stats/beneficiaire', [StatsController::class, 'beneficiaire']);
    Route::get('/stats/collectivite', [StatsController::class, 'collectivite']);

    // ── Notifications ────────────────────────────────────
    Route::get('/notifications',                    [NotificationController::class, 'index']);
    Route::put('/notifications/{id}/lire',          [NotificationController::class, 'marquerLue']);
    Route::put('/notifications/lire-toutes',        [NotificationController::class, 'marquerToutesLues']);
});
