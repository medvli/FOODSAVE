<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'name',
        'description',
        'category',
        'quantity',
        'unit',
        'expiration_date',
        'available_until',
        'action_type',
        'price',
        'status',
        'image',
        'latitude',
        'longitude',
        'ia_suggested',
    ];

    protected $casts = [
        'expiration_date' => 'date',
        'price' => 'decimal:2',
        'ia_suggested' => 'boolean',
        'latitude' => 'decimal:7',
        'longitude' => 'decimal:7',
    ];

    // ─── Relations ───────────────────────────────────────────────

    // Le commerçant qui a publié ce surplus
    public function commercant()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    // Réservations faites sur ce produit
    public function reservations()
    {
        return $this->hasMany(Reservation::class);
    }

    // ─── Scopes ──────────────────────────────────────────────────

    // Produits encore disponibles
    public function scopeDisponible($query)
    {
        return $query->where('status', 'disponible')
                     ->where('expiration_date', '>=', now()->toDateString());
    }

    // Produits urgents (périmant aujourd'hui ou demain)
    public function scopeUrgent($query)
    {
        return $query->where('expiration_date', '<=', now()->addDay()->toDateString())
                     ->where('status', 'disponible');
    }

    // Produits à proximité (rayon en km)
    public function scopeProximite($query, float $lat, float $lng, float $rayon = 5)
    {
        return $query->selectRaw("*, 
            ( 6371 * acos( cos( radians(?) ) 
            * cos( radians( latitude ) ) 
            * cos( radians( longitude ) - radians(?) ) 
            + sin( radians(?) ) 
            * sin( radians( latitude ) ) ) ) AS distance", [$lat, $lng, $lat])
            ->having('distance', '<=', $rayon)
            ->orderBy('distance');
    }

    // ─── Helpers ─────────────────────────────────────────────────

    // Quantité encore disponible (total - déjà réservée)
    public function getQuantiteRestanteAttribute(): int
    {
        $reserve = $this->reservations()
            ->whereIn('status', ['en_attente', 'confirmee'])
            ->sum('quantity_reserved');
        return max(0, $this->quantity - $reserve);
    }

    // Calcul CO2 économisé (environ 2.5 kg CO2 par kg de nourriture évitée)
    public function getCo2EconomiséAttribute(): float
    {
        return round($this->quantity * 2.5, 2);
    }
}
