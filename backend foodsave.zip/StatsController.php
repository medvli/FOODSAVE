<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Reservation;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StatsController extends Controller
{
    /**
     * GET /api/stats/global
     * Statistiques globales de la plateforme (Section Impact du site)
     */
    public function global()
    {
        $repasCollectes = Reservation::where('status', 'collectee')
            ->sum('quantity_reserved');

        $co2Evite = round($repasCollectes * 2.5, 1); // 2.5 kg CO2 par repas

        $dechetsReduits = round($repasCollectes * 0.4, 1); // 400g de déchets par repas moyen

        $personnesAidees = User::whereIn('role', ['association', 'beneficiaire'])
            ->whereHas('reservations', fn($q) => $q->where('status', 'collectee'))
            ->count();

        $commercantsPartenaires = User::where('role', 'commercant')
            ->whereHas('products')
            ->count();

        $associationsActives = User::where('role', 'association')
            ->whereHas('reservations', fn($q) => $q->where('status', 'collectee'))
            ->count();

        return response()->json([
            'repas_sauves'           => (int) $repasCollectes,
            'tonnes_co2_evitees'     => round($co2Evite / 1000, 2),
            'tonnes_dechets_reduits' => round($dechetsReduits / 1000, 2),
            'personnes_aidees'       => $personnesAidees,
            'commercants_partenaires'=> $commercantsPartenaires,
            'associations_actives'   => $associationsActives,
        ]);
    }

    /**
     * GET /api/stats/commercant
     * Tableau de bord du commerçant connecté
     */
    public function commercant(Request $request)
    {
        if (!$request->user()->isCommercant()) {
            return response()->json(['message' => 'Accès refusé.'], 403);
        }

        $userId = $request->user()->id;

        // Produits de ce commerçant
        $produits = Product::where('user_id', $userId);

        $repasCollectes = Reservation::whereHas('product', fn($q) => $q->where('user_id', $userId))
            ->where('status', 'collectee')
            ->sum('quantity_reserved');

        $co2Economise = round($repasCollectes * 2.5);
        $dechetsEvites = round($repasCollectes * 0.4);

        // Produits actifs
        $produitsDisponibles = $produits->where('status', 'disponible')->count();
        $produitsUrgents = $produits->urgent()->count();

        // Économies pour le commerçant (valorisation des invendus)
        $valeurRecuperee = Reservation::whereHas('product', fn($q) => $q->where('user_id', $userId))
            ->where('status', 'collectee')
            ->join('products', 'reservations.product_id', '=', 'products.id')
            ->sum(DB::raw('reservations.quantity_reserved * products.price'));

        // Produits récents avec leurs réservations
        $derniersProduits = Product::where('user_id', $userId)
            ->withCount(['reservations' => fn($q) => $q->whereIn('status', ['en_attente', 'confirmee'])])
            ->orderByDesc('created_at')
            ->limit(5)
            ->get();

        return response()->json([
            'repas_sauves_ce_mois' => (int) $repasCollectes,
            'dechets_evites_kg'    => (int) $dechetsEvites,
            'co2_economise_kg'     => (int) $co2Economise,
            'valeur_recuperee_dt'  => round($valeurRecuperee, 2),
            'produits_disponibles' => $produitsDisponibles,
            'produits_urgents'     => $produitsUrgents,
            'derniers_produits'    => $derniersProduits,
        ]);
    }

    /**
     * GET /api/stats/association
     * Tableau de bord de l'association connectée
     */
    public function association(Request $request)
    {
        if (!$request->user()->isAssociation()) {
            return response()->json(['message' => 'Accès refusé.'], 403);
        }

        $userId = $request->user()->id;

        $collectesRealisees = Reservation::where('user_id', $userId)
            ->where('status', 'collectee')
            ->count();

        $personnesAidees = Reservation::where('user_id', $userId)
            ->where('status', 'collectee')
            ->sum('quantity_reserved');

        // Calcul de la note moyenne reçue
        $noteMoyenne = \App\Models\Rating::where('to_user_id', $userId)->avg('score') ?? 0;

        // Produits à proximité disponibles
        $user = $request->user();
        $produitsDisponibles = 0;
        if ($user->latitude && $user->longitude) {
            $produitsDisponibles = Product::disponible()
                ->proximite($user->latitude, $user->longitude, 10)
                ->count();
        }

        return response()->json([
            'personnes_aidees'       => (int) $personnesAidees,
            'collectes_realisees'    => $collectesRealisees,
            'note_satisfaction'      => round($noteMoyenne, 1),
            'produits_disponibles_proximite' => $produitsDisponibles,
        ]);
    }

    /**
     * GET /api/stats/beneficiaire
     * Tableau de bord du bénéficiaire
     */
    public function beneficiaire(Request $request)
    {
        if (!$request->user()->isBeneficiaire()) {
            return response()->json(['message' => 'Accès refusé.'], 403);
        }

        $userId = $request->user()->id;

        $repasRecuperes = Reservation::where('user_id', $userId)
            ->where('status', 'collectee')
            ->sum('quantity_reserved');

        $economiesRealisees = Reservation::where('user_id', $userId)
            ->where('status', 'collectee')
            ->join('products', 'reservations.product_id', '=', 'products.id')
            ->sum(DB::raw('reservations.quantity_reserved * products.price'));

        $impactEnvironnemental = round($repasRecuperes * 2.5); // kg CO2

        return response()->json([
            'repas_recuperes'        => (int) $repasRecuperes,
            'economies_realisees_dt' => round($economiesRealisees, 2),
            'impact_environnemental_kg_co2' => $impactEnvironnemental,
        ]);
    }

    /**
     * GET /api/stats/collectivite
     * Tableau de bord collectivité (vue territoire)
     */
    public function collectivite(Request $request)
    {
        if (!$request->user()->isCollectivite()) {
            return response()->json(['message' => 'Accès refusé.'], 403);
        }

        $ville = $request->input('city', $request->user()->city);

        // Filtrer par ville si disponible
        $usersVille = User::when($ville, fn($q) => $q->where('city', $ville));

        $commercants = (clone $usersVille)->where('role', 'commercant')->count();
        $associations = (clone $usersVille)->where('role', 'association')->count();
        $beneficiaires = (clone $usersVille)->where('role', 'beneficiaire')->count();

        $repasTotal = Reservation::where('status', 'collectee')
            ->whereHas('user', fn($q) => $q->when($ville, fn($q2) => $q2->where('city', $ville)))
            ->sum('quantity_reserved');

        $dechetsEvites = round($repasTotal * 0.4 / 1000, 2); // en tonnes
        $co2Economise  = round($repasTotal * 2.5 / 1000, 2);  // en tonnes

        // Top commerçants du territoire
        $topCommercants = User::where('role', 'commercant')
            ->when($ville, fn($q) => $q->where('city', $ville))
            ->withCount(['products as produits_publies'])
            ->orderByDesc('produits_publies')
            ->limit(5)
            ->get(['id', 'name', 'city']);

        return response()->json([
            'commercants_partenaires' => $commercants,
            'associations_actives'    => $associations,
            'beneficiaires'           => $beneficiaires,
            'repas_sauves'            => (int) $repasTotal,
            'dechets_evites_tonnes'   => $dechetsEvites,
            'co2_economise_tonnes'    => $co2Economise,
            'top_commercants'         => $topCommercants,
            'territoire'              => $ville ?? 'National',
        ]);
    }
}
