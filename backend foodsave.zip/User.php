<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $fillable = [
        'name',
        'email',
        'password',
        'role',
        'phone',
        'address',
        'city',
        'latitude',
        'longitude',
        'is_active',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
        'is_active' => 'boolean',
    ];

    // ─── Relations ───────────────────────────────────────────────

    // Un commerçant a plusieurs produits publiés
    public function products()
    {
        return $this->hasMany(Product::class);
    }

    // Un utilisateur a plusieurs réservations (association / bénéficiaire)
    public function reservations()
    {
        return $this->hasMany(Reservation::class);
    }

    // Notifications de l'utilisateur
    public function notifications()
    {
        return $this->hasMany(Notification::class);
    }

    // ─── Helpers de rôle ─────────────────────────────────────────

    public function isCommercant(): bool
    {
        return $this->role === 'commercant';
    }

    public function isAssociation(): bool
    {
        return $this->role === 'association';
    }

    public function isBeneficiaire(): bool
    {
        return $this->role === 'beneficiaire';
    }

    public function isCollectivite(): bool
    {
        return $this->role === 'collectivite';
    }

    // ─── Statistiques du commerçant ──────────────────────────────

    public function getRepassSauvesAttribute(): int
    {
        return $this->products()
            ->whereHas('reservations', fn($q) => $q->where('status', 'collectee'))
            ->withSum('reservations', 'quantity_reserved')
            ->get()
            ->sum('reservations_sum_quantity_reserved') ?? 0;
    }

    public function getNotesAverageAttribute(): float
    {
        return round(
            \App\Models\Rating::where('to_user_id', $this->id)->avg('score') ?? 0,
            1
        );
    }
}
