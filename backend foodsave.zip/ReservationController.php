<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Reservation;
use App\Models\Notification;
use Illuminate\Http\Request;

class ReservationController extends Controller
{
    /**
     * POST /api/reservations
     * Réserver un produit (association ou bénéficiaire)
     */
    public function store(Request $request)
    {
        $user = $request->user();

        // Seules les associations et bénéficiaires peuvent réserver
        if ($user->isCommercant() || $user->isCollectivite()) {
            return response()->json([
                'message' => 'Seules les associations et bénéficiaires peuvent réserver.',
            ], 403);
        }

        $validated = $request->validate([
            'product_id'        => 'required|exists:products,id',
            'quantity_reserved' => 'required|integer|min:1',
            'note'              => 'nullable|string|max:500',
        ]);

        $product = Product::findOrFail($validated['product_id']);

        // Vérifications
        if ($product->status !== 'disponible') {
            return response()->json([
                'message' => 'Ce produit n\'est plus disponible.',
            ], 422);
        }

        if ($validated['quantity_reserved'] > $product->quantite_restante) {
            return response()->json([
                'message' => "Quantité insuffisante. Il reste seulement {$product->quantite_restante} {$product->unit}.",
            ], 422);
        }

        // Vérifier si l'utilisateur n'a pas déjà réservé ce produit
        $dejaReserve = Reservation::where('product_id', $product->id)
            ->where('user_id', $user->id)
            ->whereIn('status', ['en_attente', 'confirmee'])
            ->exists();

        if ($dejaReserve) {
            return response()->json([
                'message' => 'Vous avez déjà une réservation en cours pour ce produit.',
            ], 422);
        }

        $reservation = Reservation::create([
            'product_id'        => $product->id,
            'user_id'           => $user->id,
            'quantity_reserved' => $validated['quantity_reserved'],
            'status'            => 'en_attente',
            'note'              => $validated['note'] ?? null,
        ]);

        // Si plus de stock disponible, mettre le produit en "réservé"
        if ($product->fresh()->quantite_restante <= 0) {
            $product->update(['status' => 'reserve']);
        }

        // Notifier le commerçant
        Notification::create([
            'user_id' => $product->user_id,
            'title'   => '📦 Nouvelle réservation !',
            'message' => "{$user->name} a réservé {$validated['quantity_reserved']} {$product->unit} de {$product->name}",
            'type'    => 'nouvelle_reservation',
            'data'    => [
                'reservation_id' => $reservation->id,
                'product_id'     => $product->id,
            ],
        ]);

        return response()->json([
            'message'     => '✅ Réservation confirmée ! Instructions de collecte envoyées.',
            'reservation' => $reservation->load('product.commercant:id,name,address,phone'),
        ], 201);
    }

    /**
     * GET /api/reservations
     * Mes réservations
     */
    public function index(Request $request)
    {
        $reservations = Reservation::where('user_id', $request->user()->id)
            ->with(['product.commercant:id,name,address,city,phone'])
            ->orderByDesc('created_at')
            ->paginate(15);

        return response()->json($reservations);
    }

    /**
     * PUT /api/reservations/{id}/confirmer
     * Le commerçant confirme la réservation
     */
    public function confirmer(Request $request, int $id)
    {
        $reservation = Reservation::with('product')->findOrFail($id);

        // Seul le commerçant propriétaire peut confirmer
        if ($reservation->product->user_id !== $request->user()->id) {
            return response()->json(['message' => 'Accès refusé.'], 403);
        }

        $reservation->update(['status' => 'confirmee']);

        // Notifier le bénéficiaire / l'association
        Notification::create([
            'user_id' => $reservation->user_id,
            'title'   => '✅ Réservation confirmée !',
            'message' => "Votre réservation de {$reservation->product->name} est confirmée. Vous pouvez venir la récupérer.",
            'type'    => 'reservation_confirmee',
            'data'    => ['reservation_id' => $reservation->id],
        ]);

        return response()->json([
            'message'     => 'Réservation confirmée.',
            'reservation' => $reservation->fresh(),
        ]);
    }

    /**
     * PUT /api/reservations/{id}/collecter
     * Marquer comme collectée (produit récupéré)
     */
    public function marquerCollectee(Request $request, int $id)
    {
        $reservation = Reservation::with('product')->findOrFail($id);

        // Le commerçant ou l'utilisateur peut confirmer la collecte
        $isCommercant = $reservation->product->user_id === $request->user()->id;
        $isReservant  = $reservation->user_id === $request->user()->id;

        if (!$isCommercant && !$isReservant) {
            return response()->json(['message' => 'Accès refusé.'], 403);
        }

        $reservation->update([
            'status'       => 'collectee',
            'collected_at' => now(),
        ]);

        // Mettre à jour le produit si toutes les réservations sont collectées
        $enAttenteOuConfirmee = $reservation->product->reservations()
            ->whereIn('status', ['en_attente', 'confirmee'])
            ->count();

        if ($enAttenteOuConfirmee === 0) {
            $reservation->product->update(['status' => 'collecte']);
        }

        return response()->json([
            'message'     => '🎉 Collecte enregistrée ! Merci pour votre engagement contre le gaspillage.',
            'reservation' => $reservation->fresh(),
        ]);
    }

    /**
     * PUT /api/reservations/{id}/annuler
     * Annuler une réservation
     */
    public function annuler(Request $request, int $id)
    {
        $reservation = Reservation::with('product')->findOrFail($id);

        if ($reservation->user_id !== $request->user()->id) {
            return response()->json(['message' => 'Accès refusé.'], 403);
        }

        if ($reservation->status === 'collectee') {
            return response()->json([
                'message' => 'Impossible d\'annuler une réservation déjà collectée.',
            ], 422);
        }

        $reservation->update(['status' => 'annulee']);

        // Remettre le produit en disponible si nécessaire
        if ($reservation->product->status === 'reserve') {
            $reservation->product->update(['status' => 'disponible']);
        }

        // Notifier le commerçant
        Notification::create([
            'user_id' => $reservation->product->user_id,
            'title'   => '❌ Réservation annulée',
            'message' => "{$request->user()->name} a annulé sa réservation de {$reservation->product->name}",
            'type'    => 'reservation_annulee',
            'data'    => ['reservation_id' => $reservation->id],
        ]);

        return response()->json(['message' => 'Réservation annulée.']);
    }
}
