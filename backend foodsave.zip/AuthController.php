<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;

class AuthController extends Controller
{
    /**
     * POST /api/register
     * Inscription d'un nouvel utilisateur
     */
    public function register(Request $request)
    {
        $validated = $request->validate([
            'name'      => 'required|string|max:255',
            'email'     => 'required|email|unique:users',
            'password'  => ['required', 'confirmed', Password::min(8)],
            'role'      => 'required|in:commercant,association,beneficiaire,collectivite',
            'phone'     => 'nullable|string|max:20',
            'address'   => 'nullable|string|max:255',
            'city'      => 'nullable|string|max:100',
            'latitude'  => 'nullable|numeric',
            'longitude' => 'nullable|numeric',
        ]);

        $user = User::create([
            'name'      => $validated['name'],
            'email'     => $validated['email'],
            'password'  => Hash::make($validated['password']),
            'role'      => $validated['role'],
            'phone'     => $validated['phone'] ?? null,
            'address'   => $validated['address'] ?? null,
            'city'      => $validated['city'] ?? null,
            'latitude'  => $validated['latitude'] ?? null,
            'longitude' => $validated['longitude'] ?? null,
        ]);

        $token = $user->createToken('foodsave_token')->plainTextToken;

        return response()->json([
            'message' => 'Inscription réussie ! Bienvenue sur FoodSave.',
            'user'    => $user,
            'token'   => $token,
        ], 201);
    }

    /**
     * POST /api/login
     * Connexion d'un utilisateur existant
     */
    public function login(Request $request)
    {
        $request->validate([
            'email'    => 'required|email',
            'password' => 'required|string',
        ]);

        if (!Auth::attempt($request->only('email', 'password'))) {
            return response()->json([
                'message' => 'Email ou mot de passe incorrect.',
            ], 401);
        }

        $user  = Auth::user();

        if (!$user->is_active) {
            return response()->json([
                'message' => 'Votre compte a été désactivé. Contactez le support.',
            ], 403);
        }

        // Supprime les anciens tokens
        $user->tokens()->delete();

        $token = $user->createToken('foodsave_token')->plainTextToken;

        return response()->json([
            'message' => 'Connexion réussie !',
            'user'    => $user,
            'token'   => $token,
        ]);
    }

    /**
     * POST /api/logout
     * Déconnexion
     */
    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json([
            'message' => 'Déconnexion réussie.',
        ]);
    }

    /**
     * GET /api/me
     * Profil de l'utilisateur connecté
     */
    public function me(Request $request)
    {
        return response()->json([
            'user' => $request->user(),
        ]);
    }

    /**
     * PUT /api/profile
     * Mise à jour du profil
     */
    public function updateProfile(Request $request)
    {
        $user = $request->user();

        $validated = $request->validate([
            'name'      => 'sometimes|string|max:255',
            'phone'     => 'sometimes|nullable|string|max:20',
            'address'   => 'sometimes|nullable|string|max:255',
            'city'      => 'sometimes|nullable|string|max:100',
            'latitude'  => 'sometimes|nullable|numeric',
            'longitude' => 'sometimes|nullable|numeric',
        ]);

        $user->update($validated);

        return response()->json([
            'message' => 'Profil mis à jour.',
            'user'    => $user->fresh(),
        ]);
    }
}
