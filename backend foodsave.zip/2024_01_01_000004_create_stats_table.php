<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Statistiques globales de la plateforme
        Schema::create('impact_stats', function (Blueprint $table) {
            $table->id();
            $table->integer('total_repas_sauves')->default(0);
            $table->decimal('total_co2_evite', 10, 2)->default(0); // en kg
            $table->decimal('total_dechets_reduits', 10, 2)->default(0); // en kg
            $table->integer('total_personnes_aidees')->default(0);
            $table->integer('total_commercants')->default(0);
            $table->integer('total_associations')->default(0);
            $table->date('date');
            $table->timestamps();
        });

        // Évaluations / notes
        Schema::create('ratings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('reservation_id')->constrained()->onDelete('cascade');
            $table->foreignId('from_user_id')->constrained('users')->onDelete('cascade');
            $table->foreignId('to_user_id')->constrained('users')->onDelete('cascade');
            $table->integer('score'); // 1 à 5
            $table->text('comment')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ratings');
        Schema::dropIfExists('impact_stats');
    }
};
