<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Notification;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ProductController extends Controller
{
    /**
     * GET /api/products
     * Lister tous les produits disponibles (avec filtres)
     */
    public function index(Request $request)
    {
        $query = Product::with('commercant:id,name,city,latitude,longitude')
                        ->disponible();

        // Filtre par catégorie
        if ($request->filled('category')) {
            $query->where('category', $request->category);
        }

        // Filtre par type d'action
        if ($request->filled('action_type')) {
            $query->where('action_type', $request->action_type);
        }

        // Filtre urgent (périme aujourd'hui ou demain)
        if ($request->boolean('urgent')) {
            $query->urgent();
        }

        // Filtre par proximité (si l'utilisateur envoie sa position)
        if ($request->filled('lat') && $request->filled('lng')) {
            $rayon = $request->input('rayon', 5); // rayon par défaut 5km
            $query->proximite((float)$request->lat, (float)$request->lng, (float)$rayon);
        }

        $products = $query->paginate(20);

        return response()->json($products);
    }

    /**
     * GET /api/products/{id}
     * Voir un produit en détail
     */
    public function show(int $id)
    {
        $product = Product::with([
            'commercant:id,name,city,address,phone,latitude,longitude',
        ])->findOrFail($id);

        return response()->json($product);
    }

    /**
     * POST /api/products
     * Commerçant publie un nouveau surplus
     */
    public function store(Request $request)
    {
        // Seuls les commerçants peuvent publier
        if (!$request->user()->isCommercant()) {
            return response()->json([
                'message' => 'Seuls les commerçants peuvent publier des surplus.',
            ], 403);
        }

        $validated = $request->validate([
            'name'            => 'required|string|max:255',
            'description'     => 'nullable|string',
            'category'        => 'required|string|in:boulangerie,fruits_legumes,produits_frais,repas,epicerie,autre',
            'quantity'        => 'required|integer|min:1',
            'unit'            => 'required|string|in:kg,unité,portion,litre',
            'expiration_date' => 'required|date|after_or_equal:today',
            'available_until' => 'nullable|date_format:H:i',
            'action_type'     => 'required|in:don,prix_solidaire,redistribution',
            'price'           => 'required_if:action_type,prix_solidaire|numeric|min:0',
            'image'           => 'nullable|image|max:2048', // 2MB max
        ]);

        // Traitement de l'image si fournie
        $imagePath = null;
        if ($request->hasFile('image')) {
            $imagePath = $request->file('image')->store('products', 'public');
        }

        $product = Product::create([
            ...$validated,
            'user_id'   => $request->user()->id,
            'price'     => $validated['action_type'] === 'don' ? 0 : ($validated['price'] ?? 0),
            'image'     => $imagePath,
            'latitude'  => $request->user()->latitude,
            'longitude' => $request->user()->longitude,
            'status'    => 'disponible',
        ]);

        // Notifier les associations et bénéficiaires à proximité
        $this->notifierUtilisateursProches($product);

        return response()->json([
            'message' => 'Surplus publié avec succès ! Les associations et bénéficiaires proches ont été notifiés.',
            'product' => $product,
        ], 201);
    }

    /**
     * PUT /api/products/{id}
     * Modifier un surplus (commerçant propriétaire seulement)
     */
    public function update(Request $request, int $id)
    {
        $product = Product::findOrFail($id);

        // Vérification : seul le commerçant propriétaire peut modifier
        if ($product->user_id !== $request->user()->id) {
            return response()->json(['message' => 'Accès refusé.'], 403);
        }

        $validated = $request->validate([
            'name'            => 'sometimes|string|max:255',
            'description'     => 'sometimes|nullable|string',
            'quantity'        => 'sometimes|integer|min:0',
            'expiration_date' => 'sometimes|date',
            'available_until' => 'sometimes|nullable|date_format:H:i',
            'action_type'     => 'sometimes|in:don,prix_solidaire,redistribution',
            'price'           => 'sometimes|numeric|min:0',
            'status'          => 'sometimes|in:disponible,reserve,collecte,expire',
        ]);

        $product->update($validated);

        return response()->json([
            'message' => 'Surplus mis à jour.',
            'product' => $product->fresh(),
        ]);
    }

    /**
     * DELETE /api/products/{id}
     * Supprimer un surplus
     */
    public function destroy(Request $request, int $id)
    {
        $product = Product::findOrFail($id);

        if ($product->user_id !== $request->user()->id) {
            return response()->json(['message' => 'Accès refusé.'], 403);
        }

        // Supprimer l'image si elle existe
        if ($product->image) {
            Storage::disk('public')->delete($product->image);
        }

        $product->delete();

        return response()->json(['message' => 'Surplus supprimé.']);
    }

    /**
     * GET /api/my-products
     * Produits du commerçant connecté
     */
    public function myProducts(Request $request)
    {
        if (!$request->user()->isCommercant()) {
            return response()->json(['message' => 'Accès refusé.'], 403);
        }

        $products = Product::where('user_id', $request->user()->id)
                           ->with('reservations')
                           ->orderByDesc('created_at')
                           ->paginate(15);

        return response()->json($products);
    }

    /**
     * Notifie les associations et bénéficiaires proches d'un nouveau surplus
     */
    private function notifierUtilisateursProches(Product $product): void
    {
        if (!$product->latitude || !$product->longitude) {
            return;
        }

        $utilisateursProches = User::whereIn('role', ['association', 'beneficiaire'])
            ->where('is_active', true)
            ->whereNotNull('latitude')
            ->selectRaw("*, 
                ( 6371 * acos( cos( radians(?) ) 
                * cos( radians( latitude ) ) 
                * cos( radians( longitude ) - radians(?) ) 
                + sin( radians(?) ) 
                * sin( radians( latitude ) ) ) ) AS distance",
                [$product->latitude, $product->longitude, $product->latitude])
            ->having('distance', '<=', 10) // 10km de rayon
            ->get();

        foreach ($utilisateursProches as $utilisateur) {
            Notification::create([
                'user_id' => $utilisateur->id,
                'title'   => '🍽️ Nouveau surplus disponible !',
                'message' => "{$product->name} disponible à {$product->commercant->name} · " .
                             round($utilisateur->distance, 1) . "km de vous",
                'type'    => 'nouveau_surplus',
                'data'    => [
                    'product_id'  => $product->id,
                    'action_type' => $product->action_type,
                    'distance_km' => round($utilisateur->distance, 1),
                ],
            ]);
        }
    }
}
