# 🌿 FoodSave — Backend Laravel

Backend API REST pour le site FoodSave, plateforme de lutte contre le gaspillage alimentaire.

---

## 📋 Fonctionnalités

| Profil        | Ce qu'il peut faire |
|---------------|---------------------|
| 🏪 Commerçant  | Publier des surplus, gérer ses produits, confirmer des réservations |
| 🤝 Association | Consulter les surplus disponibles, faire des réservations, marquer les collectes |
| 👤 Bénéficiaire| Voir les produits à prix solidaire ou gratuits, réserver |
| 🏛️ Collectivité| Voir les statistiques territoriales d'impact |

---

## 🚀 Installation (étape par étape)

### 1. Prérequis
- PHP 8.2+
- Composer
- MySQL
- (Optionnel) Node.js pour le frontend

### 2. Créer le projet Laravel
```bash
composer create-project laravel/laravel foodsave-backend
cd foodsave-backend
```

### 3. Copier tous les fichiers fournis
Copiez les fichiers dans les dossiers correspondants :
```
app/Models/          → User.php, Product.php, Reservation.php, Notification.php, Rating.php
app/Http/Controllers/→ AuthController.php, ProductController.php, ReservationController.php
                       StatsController.php, NotificationController.php
database/migrations/ → tous les fichiers de migration
routes/              → api.php
```

### 4. Installer Sanctum (authentification API)
```bash
composer require laravel/sanctum
php artisan vendor:publish --provider="Laravel\Sanctum\SanctumServiceProvider"
```

### 5. Configurer la base de données
```bash
# Copier le fichier .env
cp .env.example .env

# Générer la clé de l'application
php artisan key:generate
```

Modifier `.env` avec vos identifiants MySQL :
```env
DB_DATABASE=foodsave
DB_USERNAME=root
DB_PASSWORD=votre_mot_de_passe
```

Créer la base de données :
```bash
mysql -u root -p -e "CREATE DATABASE foodsave;"
```

### 6. Exécuter les migrations
```bash
php artisan migrate
```

### 7. Configurer le stockage des images
```bash
php artisan storage:link
```

### 8. Lancer le serveur
```bash
php artisan serve
```
L'API est accessible sur `http://localhost:8000/api`

---

## 📡 Documentation des Routes API

### 🔓 Routes publiques (sans connexion)

| Méthode | Route | Description |
|---------|-------|-------------|
| POST | `/api/register` | Créer un compte |
| POST | `/api/login` | Se connecter |
| GET | `/api/products` | Voir tous les surplus disponibles |
| GET | `/api/products/{id}` | Détail d'un produit |
| GET | `/api/stats/global` | Statistiques globales (section Impact) |

### 🔐 Routes protégées (token requis dans le header)

**Header à envoyer :** `Authorization: Bearer {votre_token}`

#### Profil
| Méthode | Route | Description |
|---------|-------|-------------|
| GET | `/api/me` | Mon profil |
| PUT | `/api/profile` | Modifier mon profil |
| POST | `/api/logout` | Se déconnecter |

#### Commerçant — Gestion des surplus
| Méthode | Route | Description |
|---------|-------|-------------|
| POST | `/api/products` | Publier un surplus |
| PUT | `/api/products/{id}` | Modifier un surplus |
| DELETE | `/api/products/{id}` | Supprimer un surplus |
| GET | `/api/my-products` | Mes surplus |
| GET | `/api/stats/commercant` | Mon tableau de bord |

#### Association / Bénéficiaire — Réservations
| Méthode | Route | Description |
|---------|-------|-------------|
| POST | `/api/reservations` | Réserver un produit |
| GET | `/api/reservations` | Mes réservations |
| PUT | `/api/reservations/{id}/confirmer` | Confirmer (commerçant) |
| PUT | `/api/reservations/{id}/collecter` | Marquer comme collecté |
| PUT | `/api/reservations/{id}/annuler` | Annuler |

#### Statistiques
| Méthode | Route | Description |
|---------|-------|-------------|
| GET | `/api/stats/association` | Tableau de bord association |
| GET | `/api/stats/beneficiaire` | Tableau de bord bénéficiaire |
| GET | `/api/stats/collectivite` | Tableau de bord collectivité |

#### Notifications
| Méthode | Route | Description |
|---------|-------|-------------|
| GET | `/api/notifications` | Mes notifications |
| PUT | `/api/notifications/{id}/lire` | Marquer comme lue |
| PUT | `/api/notifications/lire-toutes` | Tout marquer comme lu |

---

## 🧪 Tester avec Postman

### Exemple 1 : Inscription d'un commerçant
```json
POST /api/register
{
  "name": "Boulangerie Amayma",
  "email": "amayma@example.com",
  "password": "password123",
  "password_confirmation": "password123",
  "role": "commercant",
  "city": "Tunis",
  "latitude": 36.8065,
  "longitude": 10.1815
}
```

### Exemple 2 : Publier un surplus
```json
POST /api/products
Authorization: Bearer {token}
{
  "name": "Pain complet",
  "category": "boulangerie",
  "quantity": 15,
  "unit": "unité",
  "expiration_date": "2026-02-28",
  "available_until": "20:00",
  "action_type": "don",
  "price": 0
}
```

### Exemple 3 : Réserver un produit
```json
POST /api/reservations
Authorization: Bearer {token}
{
  "product_id": 1,
  "quantity_reserved": 5,
  "note": "Je passerai vers 18h"
}
```

### Exemple 4 : Produits proches de moi
```
GET /api/products?lat=36.8065&lng=10.1815&rayon=3&urgent=true
```

---

## 🗂️ Structure des fichiers

```
foodsave-backend/
├── .env.example                          ← Configuration
├── routes/
│   └── api.php                           ← Toutes les routes API
├── app/
│   ├── Models/
│   │   ├── User.php                      ← Utilisateurs (4 profils)
│   │   ├── Product.php                   ← Surplus alimentaires
│   │   ├── Reservation.php               ← Réservations
│   │   ├── Notification.php              ← Notifications
│   │   └── Rating.php                    ← Évaluations
│   └── Http/Controllers/
│       ├── AuthController.php            ← Inscription / Connexion
│       ├── ProductController.php         ← Gestion des surplus
│       ├── ReservationController.php     ← Réservations
│       ├── StatsController.php           ← Tableaux de bord
│       └── NotificationController.php   ← Notifications
└── database/migrations/
    ├── ..._create_users_table.php
    ├── ..._create_products_table.php
    ├── ..._create_reservations_table.php
    └── ..._create_stats_table.php
```

---

## 🔄 Connecter le Frontend (FOODSAVE.html)

Pour connecter votre site HTML au backend, remplacez les fonctions JavaScript :

```javascript
// Remplacer la fonction addProduct()
async function addProduct(event) {
    event.preventDefault();
    const form = event.target;
    
    const response = await fetch('http://localhost:8000/api/products', {
        method: 'POST',
        headers: {
            'Authorization': 'Bearer ' + localStorage.getItem('token'),
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            name: form.querySelector('[name="name"]').value,
            quantity: form.querySelector('[name="quantity"]').value,
            expiration_date: form.querySelector('[name="expiration_date"]').value,
            action_type: form.querySelector('select').value,
            category: 'autre',
            unit: 'unité',
        })
    });
    
    const data = await response.json();
    showToast(data.message);
}

// Remplacer la fonction reserveProduct()
async function reserveProduct(productId) {
    const response = await fetch('http://localhost:8000/api/reservations', {
        method: 'POST',
        headers: {
            'Authorization': 'Bearer ' + localStorage.getItem('token'),
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            product_id: productId,
            quantity_reserved: 1,
        })
    });
    
    const data = await response.json();
    showToast(data.message);
}
```

---

## 📊 Base de données — Schéma

```
users               products            reservations
─────────           ────────            ────────────
id                  id                  id
name                user_id ──────→ users.id
email               name                product_id ──→ products.id
password            category            user_id ────→ users.id
role (4 types)      quantity            quantity_reserved
phone               expiration_date     status
city                action_type         collected_at
latitude            price               note
longitude           status
is_active           latitude/longitude

notifications       ratings
─────────────       ───────
id                  id
user_id             reservation_id
title               from_user_id
message             to_user_id
type                score (1-5)
is_read             comment
data (JSON)
```

---

*Backend développé pour FoodSave — Réduire le gaspillage alimentaire ensemble 🌿*
